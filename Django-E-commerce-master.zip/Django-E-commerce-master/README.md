###Project Name:Django eCommerce  Project

###Project Description: Building a eCommerce site from scratch.I'll be using open-source software to create each aspect of a fully functioning eCommerce business.
